package ru.startandroid.develop.simplecalculator; // замените на свой фактический пакет

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.app.Activity;
import ru.startandroid.develop.simplecalculator.R;


public class MainActivity extends Activity implements View.OnClickListener {

    EditText etNum1, etNum2;
    Button btnAdd, btnSub, btnMult, btnDiv;
    TextView tvResult;
    String oper = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);

        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMult = findViewById(R.id.btnMult);
        btnDiv = findViewById(R.id.btnDiv);

        tvResult = findViewById(R.id.tvResult);

        btnAdd.setOnClickListener(this);
        btnSub.setOnClickListener(this);
        btnMult.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        float num1, num2, result = 0;

        if (TextUtils.isEmpty(etNum1.getText()) || TextUtils.isEmpty(etNum2.getText())) {
            tvResult.setText("Введите оба числа");
            return;
        }

        try {
            num1 = Float.parseFloat(etNum1.getText().toString());
            num2 = Float.parseFloat(etNum2.getText().toString());
        } catch (NumberFormatException e) {
            tvResult.setText("Неверный формат числа");
            return;
        }

        int id = v.getId();

        if (id == R.id.btnAdd) {
            oper = "+";
            result = num1 + num2;
        } else if (id == R.id.btnSub) {
            oper = "-";
            result = num1 - num2;
        } else if (id == R.id.btnMult) {
            oper = "*";
            result = num1 * num2;
        } else if (id == R.id.btnDiv) {
            oper = "/";
            if (num2 == 0) {
                tvResult.setText("Деление на 0 невозможно");
                return;
            }
            result = num1 / num2;
        }

        // 🔽 ВЫВОДИМ РЕЗУЛЬТАТ
        tvResult.setText(num1 + " " + oper + " " + num2 + " = " + result);
    }

}
